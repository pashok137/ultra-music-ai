ULTRA MUSIC AI PWA starter v0.2
Files: index.html, manifest.webmanifest, sw.js.
To install as a home-screen PWA, publish these files on an HTTPS host (for example GitHub Pages), open the HTTPS address in Android Chrome, then choose Install app / Add to Home screen.
This is a prompt maker only. Direct AI audio generation and MP3 export are not connected yet; those require an authorized music-generation API/backend and may not be free.
